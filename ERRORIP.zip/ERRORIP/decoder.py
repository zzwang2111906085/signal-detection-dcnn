import numpy as np
from global_settings import *

# STATEN = 64  # 64种状态
#
# TAIL = 6  #
#
# BITN = 576  # 包的长度
# DATA_BITN = 288  # 编码钱长度
# TAIL = 6  #　原始数据尾部长度
# CRC_BITN = 32 # 32位校验码
# ORIGINAL_DATA = DATA_BITN-TAIL-CRC_BITN  # 250
#
# OneBySqrt2 = 0.7071067812


def state_model():
	"""state_table的初始化"""

	# extern struct StateInfo state_table[STATEN][2];

	class State:
		output0 = None
		output1 = None
		next_state = None
		pre_state = None

	# 完成对state_table的结构化
	state_table = []
	for i in range(0, STATEN):
		st = []
		for j in range(0, 2):
			ss = State()
			ss.output0 = 0
			ss.output1 = 0
			ss.next_state = 0
			ss.pre_state = 0
			st.append(ss)

		state_table.append(st)

	# 下面初始化state_table
	s = list(np.zeros([TAIL]))  # 生成长度位6的列表
	for state in range(STATEN):
		state = state & 0xffffffff
		for k in range(TAIL):
			s[k] = (state >> k) & 0x1

		for init in range(0, 2):

			init = init & 0xffffffff

			# encoder1
			state_table[state][init].output0 = init ^ s[4] ^ s[3] ^ s[1] ^ s[0]
			# encoder2
			state_table[state][init].output1 = init ^ s[5] ^ s[4] ^ s[3] ^ s[0]

			state_table[state][init].next_state = (init << 5) + (s[5] << 4) + (s[4] << 3) + (s[3] << 2) + (s[2] << 1) + s[1]
			state_table[state][init].pre_state = (s[4] << 5) + (s[3] << 4) + (s[2] << 3) + (s[1] << 2) + (s[0] << 1) + init

	return state_table


def MAP_decode(signal):

	alpha = np.zeros([DATA_BITN + 1, STATEN])
	beta = np.zeros([DATA_BITN + 1, STATEN])
	gamma = np.zeros([DATA_BITN, STATEN, STATEN])
	decode_data = np.zeros(DATA_BITN)

	state_table = state_model()  # 初始化状态表

	# 初始化aipha和beta数组
	alpha, beta = Set_Metric(alpha, beta)

	# 前向迭代
	alpha, gamma = ForwardRecursion(signal, alpha, gamma, state_table)
	# 后向迭代
	beta = BackwardRecursion(beta, gamma, state_table)
	# 计算最大路径
	LLR = LLR_calculation(alpha, gamma, beta, state_table)
	# 解码
	decode_data = LLRoutput(LLR, decode_data)

	return decode_data


def Set_Metric(alpha: np.ndarray, beta: np.ndarray):
	"""
	alpha:初始化第一行
	beta:初始化最后一行
	"""

	for state in range(0, STATEN):  # 64种状态

		if state == 0:
			alpha[0][state] = 0.0
			beta[DATA_BITN][state] = 0.0

		else:
			alpha[0][state] = -1.0e4
			beta[DATA_BITN][state] = -1.0e4

	return alpha, beta


def ForwardRecursion(signal: np.ndarray, alpha: np.ndarray, gamma: np.ndarray, state_table):
	"""
	前向迭代完成alpha和gamma的初始化
	"""
	bit = list(np.zeros([2]))  # 生成长度位2的列表
	tsignal = list(np.zeros([2]))  # 生成长度位2的列表
	Metric = list(np.zeros([2]))  # 生成长度位2的列表
	bin2sgnl = [-OneBySqrt2, OneBySqrt2]

	for n in range(0, DATA_BITN):
		for state in range(0, STATEN):
			for path in range(0, 2):

				prior_s = state_table[state][path].pre_state
				input1 = (state >> 5) & 0x1
				input1 = input1 & 0xffffffff

				bit[0] = state_table[prior_s][input1].output0
				bit[1] = state_table[prior_s][input1].output1

				tsignal[0] = bin2sgnl[bit[0]]
				tsignal[1] = bin2sgnl[bit[1]]

				Metric[path] = signal[2 * n] * tsignal[0]
				Metric[path] += signal[2 * n + 1] * tsignal[1]
				gamma[n][prior_s][state] = Metric[path]
				Metric[path] += alpha[n][prior_s]

			max_path = 0
			if Metric[0] < Metric[1]:
				max_path = 1
			alpha[n + 1][state] = Metric[max_path]

	return alpha, gamma


def BackwardRecursion(beta, gamma, state_table):
	"""
	将beta数组初始化
	"""

	# int n, state, path, max_path, next;
	Metric = list(np.zeros([2]))  # 生成长度位2的列表

	for n in range(DATA_BITN - 1, -1, -1):
		for state in range(0, STATEN):
			for path in range(0, 2):
				next_s = state_table[state][path].next_state
				Metric[path] = gamma[n][state][next_s]
				Metric[path] += beta[n + 1][next_s]

			max_path = 0
			if Metric[0] < Metric[1]:
				max_path = 1
			beta[n][state] = Metric[max_path]

	return beta


def LLR_calculation(alpha, gamma, beta, state_table):

	MaxMetric = list(np.zeros([2]))  # 生成长度位2的列表
	bitMetric0 = list(np.zeros([2]))  # 生成长度位2的列表
	bitMetric1 = list(np.zeros([2]))  # 生成长度位2的列表

	# diLLR[Tx][BITN], LLR[Tx][DATA_BITN], bitLLR[Tx][BITN]

	LLR = np.zeros([DATA_BITN])  # 生成长度位DATA_BITN的列表
	bitLLR = np.zeros([BITN])  # 生成长度位BITN的列表

	for n in range(0, DATA_BITN):
		bitMetric0[0] = -1.0e4
		bitMetric0[1] = -1.0e4
		bitMetric1[0] = -1.0e4
		bitMetric1[1] = -1.0e4

		for input1 in range(0, 2):
			for state in range(0, STATEN):
				next_s = state_table[state][input1].next_state
				bit0 = state_table[state][input1].output0
				bit1 = state_table[state][input1].output1
				Metric = alpha[n][state] + gamma[n][state][next_s] + beta[n + 1][next_s]
				if MaxMetric[input1] < Metric or state == 0:
					MaxMetric[input1] = Metric
				if bitMetric0[bit0] < Metric:
					bitMetric0[bit0] = Metric
				if bitMetric1[bit1] < Metric:
					bitMetric1[bit1] = Metric

		LLR[n] = MaxMetric[1] - MaxMetric[0]
		bitLLR[2 * n] = bitMetric0[1] - bitMetric0[0]
		bitLLR[2 * n + 1] = bitMetric1[1] - bitMetric1[0]

	return LLR


def LLRoutput(LLR: np.ndarray, bit: np.ndarray):
	"""
	bit用于保存解码后的数据
	"""
	for n in range(0, DATA_BITN):
		if LLR[n] >= 0.0:
			bit[n] = 1

		else:
			bit[n] = 0

	return bit



