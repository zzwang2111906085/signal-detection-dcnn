import numpy as np
from crc32 import *
from global_settings import *
from decoder import *
import matplotlib.pyplot as plt


# BITN = 576  # 包的长度
# DATA_BITN = 288  # 编码钱长度
# TAIL = 6  #　原始数据尾部长度
# CRC_BITN = 32 # 32位校验码
# ORIGINAL_DATA = DATA_BITN-TAIL-CRC_BITN  # 250


def channel_encoder(bits):
    """
    bits:位需要编码的比特串，288比特，编码后为576比特,最后返回编码好的数据
    """

    bits = bits.astype(np.int32)
    encode_data = np.zeros([BITN])  # 生成一个BITN空间的列表
    s = list(np.zeros([TAIL]))  # 生成一个TAIL空间的列表
    state = 0
    for bit_index in range(DATA_BITN):  # 循环288次
        for k in range(TAIL):
            s[k] = (state >> k) & 0x1  # 初始化6个状态

        # encoder1
        encode_data[bit_index * 2] = bits[bit_index] ^ s[4] ^ s[3] ^ s[1] ^ s[0]
        # encoder2
        encode_data[bit_index * 2 + 1] = bits[bit_index] ^ s[5] ^ s[4] ^ s[3] ^ s[0]

        # 状态更新
        state = (bits[bit_index] << 5) + (s[5] << 4) + (s[4] << 3) + (s[3] << 2) + (s[2] << 1) + s[1]
        state = state & 0xffffffff

    return np.array(encode_data)


def conv_encode(original_data: np.ndarray):
    """
    original_data:原始数据250比特
    """
    data = np.zeros([DATA_BITN])  # 288list()
    data[:ORIGINAL_DATA] = original_data[:]  # 250比特
    # TODO 32位的crc校验码
    data[ORIGINAL_DATA:-TAIL] = crc32(original_data)  # 获得32位的crc校验码

    #尾部追加6个0
    for j in range(DATA_BITN - TAIL, DATA_BITN):
        data[j] = 0  # 追加6个0

    # 编码
    encode_data = channel_encoder(data)

    return encode_data, data


def conv_encode_no_tail(original_data: np.ndarray):
    """

    :param original_data: 原始[0，1]数据串，长度位data_length
    :return: encode_bits and crc_bits
    """

    data = np.zeros([DATA_BITN])
    data[:DATA_LENGTH] = original_data[:]
    data[DATA_LENGTH:DATA_BITN] = crc32(original_data)  # 获得32位校验码

    encode_bits = channel_encoder(data)  # 编码

    return encode_bits, data
