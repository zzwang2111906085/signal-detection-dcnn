import commpy.channelcoding.convcode as cc
import matplotlib.pyplot as plt

from global_settings import *

QPSK_CANDIDATE_SIZE = 2 ** (2 * NUM_ANT)  # 256
QPSK_CANDIDATES = np.array([x for x in itertools.product([1, -1], repeat=2 * NUM_ANT)]).T / np.sqrt(2)


def concatenate(total, part):
    return part if total is None else np.concatenate((total, part))


def get_qpsk_bits(s):
    """解调数据"""
    # ---->[0,1]
    return np.where(s < 0, 0, 1)


def qpsk(bits: np.ndarray):
    """qbsk调制"""
    # [0, 1]--->[qbsk数据]
    return (bits * 2 - 1) / np.sqrt(2)


def hard_llr(bits):
    # [0, 1] ----->[-1, 1]
    return 2 * bits - 1


def qpsk_symbol_decision(z):
    """qbsk信号调制"""
    return np.where(z < 0, -1., 1.) / np.sqrt(2)


def zero_forcing(y: np.ndarray, h: np.ndarray):
    assert len(y.shape) == 2
    z = np.linalg.inv(h.T @ h) @ h.T @ y
    s = qpsk_symbol_decision(z)
    return s


def mld(y, h):
    """完成二维的QPSK-MLD"""
    # assert len(y.shape) == 2
    dst = np.sum(np.square(y - h @ QPSK_CANDIDATES), axis=0)
    idx = dst.argmin()
    s_est = QPSK_CANDIDATES[:, idx].reshape([2 * NUM_ANT, 1])
    return s_est


def mld_ird(y, h):
    """三维的QPSK-MLD"""
    dis = np.sum(np.square(y - h @ QPSK_CANDIDATES), axis=1)
    min_indexs = dis.argmin(1)

    x_mld = None
    for t in min_indexs:
        s = QPSK_CANDIDATES[:, t]
        s = s.reshape([1, 2 * NUM_ANT, 1])
        x_mld = concatenate(x_mld, s)
    return x_mld


def zf_batch(y, h):
    h_t = h.transpose([0, 2, 1])
    z = np.linalg.inv(h_t @ h) @ h_t @ y
    hat_s = np.where(z < 0, -1, 1)
    return hat_s / np.sqrt(2)


# used
def mmse_batch_fast(y, h):
    eye = np.eye(2 * NUM_ANT).reshape([1, 2 * NUM_ANT, 2 * NUM_ANT])
    h_t = np.transpose(h, axes=[0, 2, 1])
    z = np.linalg.inv(h_t @ h + eye) @ h_t @ y
    hat_s = np.where(z < 0, -1, 1)
    return hat_s / np.sqrt(2)


def mmse_batch(y, h):
    result = None
    times = int(y.size / (NUM_ANT * 2))
    for i in range(times):
        y = y[i, :, :]
        h = h[i, :, :]
        h_t = h.transpose()

        z = np.linalg.inv(h_t @ h + np.eye(NUM_ANT * 2)) @ h_t @ y
        hat_s = np.where(z < 0, -1, 1)
        hat_s = hat_s.reshape([1, NUM_ANT * 2, 1])
        result = concatenate(result, hat_s)
    return result


def time_corrected_w(i, rho, pre_w):
    """产生具有时间相关性的w"""
    u = np.random.randn(1, 2 * NUM_ANT, 1)
    if i == 0:
        w = u
    else:
        w = np.sqrt(rho) * pre_w + np.sqrt(1 - rho) * u
    return w


def xxx_mld_batch(init_detector, y, h):
    s_init = init_detector(y, h)

    s_cand = s_init
    dst_cand = np.sum((y - h @ s_init) ** 2, axis=1)

    for i in range(NUM_ANT):
        # real
        real_mask = np.ones_like(s_init)
        real_mask[:, i:i + 1, :] *= -1

        # imaginary
        imag_mask = np.ones_like(s_init)
        imag_mask[:, i + NUM_ANT:i + NUM_ANT + 1, :] *= -1

        # both real and imaginary
        real_imag_mask = real_mask * imag_mask

        # find candidates
        mask_list = [real_mask, imag_mask, real_imag_mask]
        for mask in mask_list:
            s_possible = s_init * mask
            dst_possible = np.sum((y - h @ s_possible) ** 2, axis=1)

            s_cand = np.concatenate((s_cand, s_possible), axis=2)
            dst_cand = np.concatenate((dst_cand, dst_possible), axis=1)

    min_indexes = dst_cand.argmin(1)

    s_estimated_batch = None
    for t, index in enumerate(min_indexes):
        s_estimated = s_cand[t, :, index]
        s_estimated = s_estimated.reshape([1, 2 * NUM_ANT, 1])
        s_estimated_batch = concatenate(s_estimated_batch, s_estimated)

    return s_estimated_batch


def count_error(a, b):
    assert a.shape == b.shape
    return np.argwhere(a != b).size


# def generate_data():
#     generate_bits()

def get_pack_s():
    """产生一个包的训练数据"""
    s_pack = None
    one_hot = np.zeros([TIMES_SLOTS_PER_PACKET, QPSK_CANDIDATE_SIZE])
    random_index = np.random.uniform(0, QPSK_CANDIDATE_SIZE, size=TIMES_SLOTS_PER_PACKET)
    for t in range(TIMES_SLOTS_PER_PACKET):  # 64
        index = int(random_index[t])
        one_hot[t, index] = 1
        s = QPSK_CANDIDATES[:, index:index + 1]
        s = s.reshape([1, 2 * NUM_ANT, 1])
        s_pack = concatenate(s_pack, s)

    return s_pack, one_hot


def generate_train_bits(rho=0.5, snr=10):
    """产生数据"""
    packet_signal, one_hot = get_pack_s()  # 生成一个包的数据和独热编码

    assert packet_signal.size % (2 * NUM_ANT) == 0
    transmit_times = int(packet_signal.size / (2 * NUM_ANT))

    # 整个包数据
    packet_y = None
    packet_h = None
    packet_s = None
    packet_w = None
    packet_hat_s = None
    packet_hat_w = None

    power = 10 ** (snr / 10)

    for j in range(transmit_times):  # 每个包发送次数
        # 发送端

        s = packet_signal[j]

        s = np.reshape(s, [1, 2 * NUM_ANT, 1])

        h = np.sqrt(power / NUM_ANT) * complex_channel(NUM_ANT, NUM_ANT)
        h = np.reshape(h, [1, NUM_ANT * 2, NUM_ANT * 2])
        if j == 0:
            w = np.random.randn(1, 2 * NUM_ANT, 1)
            pre_w = w

        else:
            u = np.random.randn(1, 2 * NUM_ANT, 1)
            w = np.sqrt(rho) * pre_w + np.sqrt(1 - rho) * u
            pre_w = w

        # AWGN channel
        y = h @ s + w

        # 接收端, h 完美估计
        if DETECTOR_TYPE == MMSE:
            hat_s = xxx_mld_batch(mmse_batch_fast, y, h)
            # hat_s = mmse_batch_fast(y, h)
        elif DETECTOR_TYPE == ZF:
            hat_s = xxx_mld_batch(zf_batch, y, h)
            # hat_s = zf_batch(y, h)
        elif DETECTOR_TYPE == MLD:
            hat_s = xxx_mld_batch(mld_ird, y, h)
            # hat_s = mld_ird(y, h)
        else:
            raise Exception("Unknown detector")

        hat_w = y - h @ hat_s

        packet_y = concatenate(packet_y, y)
        packet_h = concatenate(packet_h, h)
        packet_s = concatenate(packet_s, s)  # 编码调制后的s
        packet_w = concatenate(packet_w, w)
        packet_hat_s = concatenate(packet_hat_s, hat_s)  # 获得检测后的数据
        packet_hat_w = concatenate(packet_hat_w, hat_w)  # 获得检测后的数据
        # 以上数据未解调, packet_bits为原始【0， 1】数据

    packet_data = [packet_y, packet_h, packet_s, one_hot, packet_w, packet_hat_s, packet_hat_w]
    return packet_data


def generate_bits(rho=0.5, snr=10, enable_codec=True, trill=None):
    """产生数据"""
    packet_bits = random_bits(DATA_LENGTH)

    if enable_codec:
        # packet_codes, crc_data = conv_encode(packet_bits)
        packet_codes = cc.conv_encode(packet_bits, trill)
    else:
        packet_codes = packet_bits

    packet_signal = qpsk(packet_codes)  # 调制
    assert packet_signal.size % (2 * NUM_ANT) == 0
    transmit_times = int(packet_signal.size / (2 * NUM_ANT))

    # 整个包数据
    packet_y = None
    packet_h = None
    packet_s = None
    packet_w = None
    packet_hat_s = None
    packet_hat_w = None

    power = 10 ** (snr / 10)

    one_hot = np.zeros([transmit_times, QPSK_CANDIDATE_SIZE])
    h = np.sqrt(power / NUM_ANT) * complex_channel(NUM_ANT, NUM_ANT)
    h = np.reshape(h, [1, NUM_ANT * 2, NUM_ANT * 2])

    for j in range(transmit_times):  # 每个包发送次数
        # 发送端
        left = j * 2 * NUM_ANT
        right = (j + 1) * 2 * NUM_ANT
        s = packet_signal[left:right]

        for index in range(QPSK_CANDIDATE_SIZE):
            if count_error(s.reshape([2 * NUM_ANT, 1]), QPSK_CANDIDATES[:, index: index + 1]) == 0:
                one_hot[j, index] = 1
                break

        s = np.reshape(s, [1, 2 * NUM_ANT, 1])

        if j == 0:
            w = np.random.randn(1, 2 * NUM_ANT, 1)
            pre_w = w

        else:
            u = np.random.randn(1, 2 * NUM_ANT, 1)
            w = np.sqrt(rho) * pre_w + np.sqrt(1 - rho) * u
            pre_w = w

        # AWGN channel
        y = h @ s + w

        # 接收端, h 完美估计
        if DETECTOR_TYPE == MMSE:
            hat_s = xxx_mld_batch(mmse_batch_fast, y, h)
            # hat_s = mmse_batch_fast(y, h)
        elif DETECTOR_TYPE == ZF:
            hat_s = xxx_mld_batch(zf_batch, y, h)
            # hat_s = zf_batch(y, h)
        elif DETECTOR_TYPE == MLD:
            hat_s = xxx_mld_batch(mld_ird, y, h)
            # hat_s = mld_ird(y, h)
        else:
            raise Exception("Unknown detector")
        # hat_s = zf_batch(y, h)
        # hat_s = mld_ird(y, h)
        # hat_s = mmse_batch_fast(y, h)
        # hat_s = zf_batch(y, h)
        # if DETECTOR_TYPE == ZFMLD:
        # hat_s = xxx_mld_batch(zf_batch, y, h)  # 检测后的数据
        # elif DETECTOR_TYPE == MMSEMLD:
        #     hat_s = xxx_mld_batch(mmse_batch_fast, y, h)
        # else:
        #     raise Exception("Unknown detector")

        hat_w = y - h @ hat_s

        packet_y = concatenate(packet_y, y)
        packet_h = concatenate(packet_h, h)
        packet_s = concatenate(packet_s, s)  # 编码调制后的s
        packet_w = concatenate(packet_w, w)
        packet_hat_s = concatenate(packet_hat_s, hat_s)  # 获得检测后的数据
        packet_hat_w = concatenate(packet_hat_w, hat_w)  # 获得检测后的数据
        # 以上数据未解调, packet_bits为原始【0， 1】数据

    packet_data = [packet_y, packet_h, packet_s, one_hot, packet_w, packet_hat_s, packet_hat_w]
    return packet_data, packet_bits


def random_bits(size):
    # 生成原始[0,1]数据
    return np.where(np.random.uniform(0, 1, size) < 0.5, 0., 1.)


def complex_channel(m, n):
    real = np.random.randn(m, n)
    imag = np.random.randn(m, n)
    h = np.row_stack(
        (
            np.column_stack((real, -imag)),
            np.column_stack((imag, real)),
        )
    )
    return h


def third_party_encode():
    """使用第三方编码器"""
    memory = np.array([TAIL])
    g_matrix = np.array([[1 + TAIL ** 2, 1 + TAIL + TAIL ** 2]])  # G(D) = [1+D^2, 1+D+D^2]
    trellis = cc.Trellis(memory, g_matrix)
    return trellis


def save_batch_data(packet_data, f_y, f_h, f_s, f_one_hot, f_w, f_hat_s, f_hat_w):
    """保存数据"""
    packet_data[0].astype(np.float32).tofile(f_y)
    packet_data[1].astype(np.float32).tofile(f_h)
    packet_data[2].astype(np.float32).tofile(f_s)  # 编码后的数据
    packet_data[3].astype(np.float32).tofile(f_one_hot)
    packet_data[4].astype(np.float32).tofile(f_w)
    packet_data[5].astype(np.float32).tofile(f_hat_s)  # 检测后的数据
    packet_data[6].astype(np.float32).tofile(f_hat_w)
    # pack[6].astype(np.float32).tofile(file_crc_s_batch)

    f_y.flush()
    f_h.flush()
    f_s.flush()
    f_one_hot.flush()
    f_w.flush()
    f_hat_s.flush()
    f_hat_w.flush()
    # file_crc_s_batch.flush()


def huatu():
    fig = plt.figure(6, 6)
    snr = [7, 8, 9, 10]

    k1_ber = [1.535797e-01,
              1.020099e-01,
              6.473854e-02,
              3.546198e-02
              ]
    k2_ber = [1.527234e-01,
              1.014917e-01,
              6.445729e-02,
              3.527292e-02]

    k3_ber = [1.527057e-01,
              1.014708e-01,
              6.445312e-02,
              3.527083e-02]

    plt.plot(snr, k1_ber, c='red', )

# if __name__ == '__main__':
#     generate_train_bits(0.5, 10)
