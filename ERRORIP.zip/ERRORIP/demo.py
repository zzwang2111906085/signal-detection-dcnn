from global_settings import *
import commpy.channelcoding.convcode as cc
from encoder import conv_encode, conv_encode_no_tail
from decoder import MAP_decode
from save_data import DataSet
from func import *
import multiprocessing.pool


def my_test(flag, rho, snr):
    assert BITN % (2 * NUM_ANT) == 0

    # save_data = DataSet(flag=flag, rho=0.5, sir=snr)
    save_data = DataSet(flag=flag, rho=rho, sir=snr)
    file_y, file_h, file_s, file_one_hot, file_w, file_hat_s, file_hat_w = save_data.open_all_file("wb")


    if flag == 0:
        need_packets = 100000  # 产生用于训练的误包
    elif flag == 1:
        need_packets = 4000  # 产生用于验证的误包

    packet_count = 0  # 计数传输的总的包数

    """
    map将迭代对象转换成列表，每次放一个分块进去，迭代更快，但是当迭代对象大，耗费内存大
    imap不会将迭代对象转换列表，不分块，每次发送一个可迭代对象给进程，占用内存小，但是性能不高，但是，可以通过传递大于默认值1的chunksize参数来减轻此问题
    优先使用map,但当iterator比较大时，考虑到内存，可使用imap
    """

    # if NUM_WORKERS > 0:
    #     pool = multiprocessing.pool.Pool(NUM_WORKERS, maxtasksperchild=MAX_TASKS_PER_CHILD)
    # else:
    #     pool = multiprocessing.pool.Pool(maxtasksperchild=MAX_TASKS_PER_CHILD)
    # for packet_data, packet_bits in pool.imap(generate_bits, range(need_packets)):
    # for i in range(need_packets):
    while True:
        packet_data = generate_train_bits(rho=rho, snr=snr)
        save_batch_data(packet_data, file_y, file_h, file_s, file_one_hot, file_w, file_hat_s, file_hat_w)

        packet_count += 1

        if packet_count > need_packets:
            break

    print()
    file_y.close()
    file_h.close()
    file_s.close()
    file_one_hot.close()
    file_w.close()
    file_hat_s.close()
    file_hat_w.close()
    print("{}{}数据收集完毕！".format(rho, snr))


def benchmark():
    # snr_list = [9]
    # snr_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    # rho = 0.95
    rho_list = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    snr = 15
    for rho in rho_list:
        my_test(flag=0, rho=rho, snr=snr)  # 产生训练数据
        my_test(flag=1, rho=rho, snr=snr)  # 产生验证数据
    print()



if __name__ == "__main__":

    benchmark()
