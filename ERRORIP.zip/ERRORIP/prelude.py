import itertools
import multiprocessing
import os
import pathlib
import tensorflow as tf

from global_settings import *
import numpy as np

from decoder import *
from crc32 import *
from encoder import *

BPSK_CANDIDATE_SIZE = 2 ** NUM_ANT  # 16
BPSK_CANDIDATES = np.array([x for x in itertools.product([1, -1], repeat=NUM_ANT)]).T

# RANDOM
# rho=0.0, sir=20dB, batch=1000/1000, ZF_BER=6.119062e-02, ZF_MLD_BER=2.796840e-02, MMSE_MLD_BER=6.163889e-03, MLD_BER=5.864583e-04
# MAX_MIN
# rho=0.0, sir=20dB, batch=1000/1000, ZF_BER=4.858333e-02, ZF_MLD_BER=2.570833e-02, MMSE_MLD_BER=6.939583e-03, MLD_BER=1.861111e-04
# SVD
# rho=0.0, sir=20dB, batch=1000/1000, ZF_BER=1.296875e-04, ZF_MLD_BER=7.465278e-06, MMSE_MLD_BER=4.861111e-06, MLD_BER=1.909722e-06


def jbcheck(data):
    mean_value = np.mean(data)
    s = np.mean((data - mean_value) ** 3) / (np.mean((data - mean_value) ** 2) ** (3 / 2))
    k = np.mean((data - mean_value) ** 4) / (np.mean((data - mean_value) ** 2) ** (4 / 2))
    return s ** 2 / 6 + (k - 3) ** 2 / 24


def get_bits(x):
    # [,] ->[0, 1]
    return np.where(x < 0, 0, 1)


def check(a, b):
    assert a.shape == b.shape
    return len(np.argwhere(a != b))


def random_bits(size):
    # 生成原始[0,1]数据
    return np.where(np.random.uniform(0, 1, size) < 0.5, 0., 1.)


def bpsk_symbol_decision(z):

    return np.where(z < 0, -1., 1.)


# def get_bspk_bits(bits:np.ndarray):
#     # 检测后解调[-1, 1]->[0,1]
#     return (bits + 1) / 2


def get_bspk_signal(bits: np.ndarray):
    # [0,1]->[-1,1]
    return bits * 2 - 1


def mkdir(file_path):
    folder = os.path.dirname(file_path)
    if not os.path.exists(folder):
        os.makedirs(folder)


def mkfile(file_path):
    mkdir(file_path)
    filename = pathlib.Path(file_path)
    filename.touch(exist_ok=True)


def concatenate(total, part):
    return part if total is None else np.concatenate((total, part))


def tf_concat(a, b, axis):
    if a is None:
        return b
    elif b is None:
        return a
    else:
        return tf.concat([a, b], axis=axis)


def random_h_batch():
    h_batch = None
    for _ in range(PACKETS_PER_BATCH):
        h_e = np.random.randn(1, NUM_ANT, NUM_ANT)
        for t in range(TIMES_SLOTS_PER_PACKET):
            h_batch = concatenate(h_batch, h_e)

    return h_batch


def random_h_pack():
    """一次产生一个包的h"""
    h_pack = None
    h_e = np.random.randn(1, NUM_ANT, NUM_ANT)
    for t in range(TIMES_SLOTS_PER_PACKET):
        h_pack = concatenate(h_pack, h_e)

    return h_pack


def maxmin_h_batch():
    h_batch = None
    for _ in range(PACKETS_PER_BATCH):
        h_e = None
        v_e = 0
        for _ in range(NUM_USERS):
            h = np.random.randn(1, NUM_ANT, NUM_ANT)
            v = np.min(np.sum(h**2, axis=1))
            if h_e is None or v > v_e:
                h_e = h
                v_e = v

        for _ in range(TIMES_SLOTS_PER_PACKET):
            h_batch = concatenate(h_batch, h_e)

    return h_batch


def maxmin_h_pack():
    """一次产生一个包"""
    h_pack = None
    h_e = None
    v_e = 0

    for _ in range(NUM_USERS):
        h = np.random.randn(1, NUM_ANT, NUM_ANT)
        v = np.min(np.sum(h**2, axis=1))
        if h_e is None or v > v_e:
            h_e = h
            v_e = v

    for _ in range(TIMES_SLOTS_PER_PACKET):
        h_pack = concatenate(h_pack, h_e)

    return h_pack


def svd_h_batch():
    h_batch = None
    for _ in range(PACKETS_PER_BATCH):
        h_e = None
        v_e = 0
        for _ in range(NUM_USERS):
            h = np.random.randn(NUM_ANT, NUM_ANT)
            u, s, vh = np.linalg.svd(h)
            v = np.min(s)
            if h_e is None or v > v_e:
                h_e = h.reshape(1, NUM_ANT, NUM_ANT)
                v_e = v

        for _ in range(TIMES_SLOTS_PER_PACKET):
            h_batch = concatenate(h_batch, h_e)

    return h_batch


def svd_h_pack():
    """一次产生一个包"""
    h_pack = None
    h_e = None
    v_e = 0

    for _ in range(NUM_USERS):
        h = np.random.randn(NUM_ANT, NUM_ANT)
        u, s, vh = np.linalg.svd(h)
        v = np.min(s)
        if h_e is None or v > v_e:
            h_e = h.reshape(1, NUM_ANT, NUM_ANT)
            v_e = v

    for _ in range(TIMES_SLOTS_PER_PACKET):
        h_pack = concatenate(h_pack, h_e)

    return h_pack


def random_s_batch():
    s_batch = None
    one_hot_batch = np.zeros([TIMES_SLOTS_ORIGINAL_DATA, BPSK_CANDIDATE_SIZE])
    random_indexes = np.random.uniform(low=0, high=BPSK_CANDIDATE_SIZE, size=TIMES_SLOTS_ORIGINAL_DATA)
    for t in range(TIMES_SLOTS_ORIGINAL_DATA):
        i = int(random_indexes[t])
        one_hot_batch[t, i] = 1
        s = BPSK_CANDIDATES[:, i:i + 1]
        s = s.reshape([1, NUM_ANT, 1])
        s_batch = concatenate(s_batch, s)
    return s_batch, one_hot_batch


def time_correlated_interference_batch(rho: float):
    w_batch = None
    for t in range(TIMES_SLOTS_PER_BATCH):
        u = np.random.randn(1, NUM_ANT, 1)
        if t == 0:
            w_batch = concatenate(w_batch, u)
        else:
            w_prev = w_batch[t - 1:t, :, :]
            w = np.sqrt(rho) * w_prev + np.sqrt(1 - rho) * u
            w_batch = concatenate(w_batch, w)
    return w_batch


def zf_sic(y, h):
    """
    y为接受到的信号
    h为信道
    """
    s_list = [0] * NUM_ANT

    for t in range(NUM_ANT):
        if t == 0:
            var = np.linalg.inv(h.T @ h)
            diag = var.diagonal()
            # assert (diag >= 0).all(), "{}".format(diag)

            idx_ = int(np.abs(diag).argmin())
            z = var @ h.T @ y
            s = int(np.where(z[idx_, :] < 0, -1, 1))
            s_list[idx_] = s

            y_ = y - h[:, idx_:idx_ + 1] * s
            h_ = np.delete(h, idx_, axis=1)
        else:
            var_ = np.linalg.inv(h_.T @ h_)
            diag_ = var_.diagonal()
            # assert (diag_ >= 0).all(), "{}".format(diag_)

            idx_ = int(np.abs(diag_).argmin())
            z = var_ @ h_.T @ y_
            s = int(np.where(z[idx_:idx_ + 1, :] < 0, -1, 1))

            j = 0
            for i, v in enumerate(s_list):
                if v == 0:
                    if j == idx_:
                        s_list[i] = s
                        break
                    j += 1

            if t < NUM_ANT - 1:
                y_ = y_ - h_[:, idx_:idx_ + 1] * s
                h_ = np.delete(h_, idx_, axis=1)

    return np.array(s_list).reshape([1, NUM_ANT, 1])


# 未使用
def zf_sic_batch(y_batch, h_batch):
    hat_s_batch = None
    for t in range(TIMES_SLOTS_PER_BATCH):
        hat_s = zf_sic(y_batch[t, :, :], h_batch[t, :, :])
        hat_s_batch = concatenate(hat_s_batch, hat_s)
    return hat_s_batch


def mmse_sic(y, h):
    s_list = [0] * NUM_ANT

    for t in range(NUM_ANT):
        if t == 0:
            var = np.linalg.inv(h.T @ h + np.eye(h.shape[1]))
            diag = var.diagonal()
            # assert (diag >= 0).all()

            idx_ = int(np.abs(diag).argmin())
            z = var @ h.T @ y
            s = int(np.where(z[idx_, :] < 0, -1, 1))
            s_list[idx_] = s

            y_ = y - h[:, idx_:idx_ + 1] * s
            h_ = np.delete(h, idx_, axis=1)
        else:
            var_ = np.linalg.inv(h_.T @ h_ + np.eye(h_.shape[1]))
            diag_ = var_.diagonal()
            # assert (diag_ >= 0).all()

            idx_ = int(np.abs(diag_).argmin())
            z = var_ @ h_.T @ y_
            s = int(np.where(z[idx_:idx_ + 1, :] < 0, -1, 1))

            j = 0
            for i, v in enumerate(s_list):
                if v == 0:
                    if j == idx_:
                        s_list[i] = s
                        break
                    j += 1

            if t < NUM_ANT - 1:
                y_ = y_ - h_[:, idx_:idx_ + 1] * s
                h_ = np.delete(h_, idx_, axis=1)

    return np.array(s_list).reshape([1, NUM_ANT, 1])


# 该函数未使用
def mmse_sic_batch(y_batch, h_batch):
    hat_s_batch = None
    for t in range(TIMES_SLOTS_PER_BATCH):
        hat_s = mmse_sic(y_batch[t, :, :], h_batch[t, :, :])
        hat_s_batch = concatenate(hat_s_batch, hat_s)
    return hat_s_batch


# used
def zf_batch(y, h):
    h_t = h.transpose([0, 2, 1])
    z = np.linalg.inv(h_t @ h) @ h_t @ y
    hat_s = np.where(z < 0, -1, 1)
    return hat_s


# used
def mmse_batch_fast(y, h):
    eye = np.stack([np.eye(NUM_ANT)] * TIMES_SLOTS_PER_BATCH, axis=0)
    h_t = np.transpose(h, axes=[0, 2, 1])
    z = np.linalg.inv(h_t @ h + eye) @ h_t @ y
    hat_s = np.where(z < 0, -1, 1)
    return hat_s


# unused
def mmse_batch(y_batch, h_batch):
    result = None
    for i in range(TIMES_SLOTS_PER_BATCH):
        y = y_batch[i, :, :]
        h = h_batch[i, :, :]
        h_t = h.transpose()

        z = np.linalg.inv(h_t @ h + np.eye(NUM_ANT * 2)) @ h_t @ y
        hat_s = np.where(z < 0, -1, 1)
        hat_s = hat_s.reshape([1, NUM_ANT * 2, 1])
        result = concatenate(result, hat_s)
    return result


# BPSK-MLD
def mld_batch(y, h):
    s_estimated_batch = None
    dst = np.sum(np.square(y - h @ BPSK_CANDIDATES), axis=1)
    min_indexes_on_axis_1 = np.unravel_index(dst.argmin(1), dst.shape)[1]
    for t in range(TIMES_SLOTS_PER_BATCH):
        index = min_indexes_on_axis_1[t]
        s_estimated = BPSK_CANDIDATES[:, index]
        s_estimated = s_estimated.reshape([1, NUM_ANT, 1])
        s_estimated_batch = concatenate(s_estimated_batch, s_estimated)
    return s_estimated_batch


# # QPSK-MLD
# def mld_qbsk(y, h):
#     """QBSK-MLD检测"""
#     distances = np.sum(np.square(y - h @ ))

def xxx_mld_batch(init_detector, y, h):
    s_init = init_detector(y, h)

    s_cand = s_init
    dst_cand = np.sum((y - h @ s_init) ** 2, axis=1)

    for i in range(NUM_ANT):
        mask = np.ones_like(s_init)
        mask[:, i:i + 1, :] = mask[:, i:i + 1, :] * -1

        s_possible = s_init * mask
        dst_possible = np.sum((y - h @ s_possible) ** 2, axis=1)

        s_cand = np.concatenate((s_cand, s_possible), axis=2)
        dst_cand = np.concatenate((dst_cand, dst_possible), axis=1)

    min_indexes = np.unravel_index(dst_cand.argmin(1), dst_cand.shape)

    s_estimated_batch = None
    for t in range(TIMES_SLOTS_PER_BATCH):
        index = min_indexes[1][t]
        s_estimated = s_cand[t, :, index]
        s_estimated = s_estimated.reshape([1, NUM_ANT, 1])
        s_estimated_batch = concatenate(s_estimated_batch, s_estimated)

    return s_estimated_batch


def encode(s_batch):
    """
    s_batch:原始[0,1]数据，长度256
    """
    encode_data, crc_s_batch = conv_encode(s_batch)  # encode_data是编码后的数据， crc_data是原始数据加上校验码的数据， encode_data / 2 = crc_data

    s_batch = get_bspk_signal(encode_data)  # 调制

    return s_batch.reshape([TIMES_SLOTS_PER_BATCH, NUM_ANT, 1]), crc_s_batch


def produce_data_batch(rho, sir_db):

    power = 10 ** (sir_db / 10)

    if CHANNEL_TYPE == RANDOM_H:
        h = np.sqrt(power / NUM_ANT) * random_h_batch()
    elif CHANNEL_TYPE == MAXMIN_H:
        h = np.sqrt(power / NUM_ANT) * maxmin_h_batch()
    elif CHANNEL_TYPE == SVD_H:
        h = np.sqrt(power / NUM_ANT) * svd_h_batch()
    else:
        raise Exception("Unknown user selection type")

    # 这里需要传入编码后的数据
    s_batch, one_hot = random_s_batch()  # s_batch.shape = [batch, num, 1]

    s_batch, crc_s_batch = encode(get_bits(s_batch.flatten()))  # 对s_batch进行编码，返回的是调制后的数据, crc_bits是未调制的带校验码的数据

    w = time_correlated_interference_batch(rho)

    y = h @ s_batch + w

    if DETECTOR_TYPE == ZFMLD:
        hat_s = xxx_mld_batch(zf_batch, y, h)  # 检测后的数据
    elif DETECTOR_TYPE == MMSEMLD:
        hat_s = xxx_mld_batch(mmse_batch_fast, y, h)
    else:
        raise Exception("Unknown detector")

    hat_w = y - h @ hat_s

    return y, h, s_batch, one_hot, w, hat_s, hat_w, crc_s_batch


def count_error(a, b):
    assert a.shape == b.shape
    return np.argwhere(a != b).size


def check_packet(bits: np.ndarray, crc_s_batch: np.ndarray):
    """
    s_batch:编码后的数据,未解调
    bits:为检测后的数据,未解调
    crc_s_batch:带校验码的原始数据
    """
    flag = 0  # 如果包没有出错返回0，否则返回1

    decode_data = MAP_decode(bits)  # 解码

    err_bit = count_error(decode_data[:DATA_LENGTH], crc_s_batch[:DATA_LENGTH])
    if err_bit > 0:
        flag = 1

    return flag


class DataSet:
    def __init__(self, flag, rho: float, sir: float):
        self.flag = flag
        self.rho = rho
        self.sir = sir
        self.error_packet = 0
        self.detect_error_bits = 0
        self.decode_error_bits = 0

    def __open_file(self, name, mode):

        if DETECTOR_TYPE == ZFMLD:
            prefix = "zf_mld"
        elif DETECTOR_TYPE == MMSEMLD:
            prefix = "mmse_mld"
        else:
            raise Exception("Unknown detector")

        if CHANNEL_TYPE == RANDOM_H:
            prefix += "/random"
        elif CHANNEL_TYPE == MAXMIN_H:
            prefix += "/maxmin"
        elif CHANNEL_TYPE == SVD_H:
            prefix += "/svd"
        else:
            raise Exception("Unknown user selection type")

        if self.flag == 0:
            file_name = "savedData/{}/rho{:.1f}_sir{}/train/{}".format(prefix, self.rho, self.sir, name)
        elif self.flag == 1:
            file_name = "savedData/{}/rho{:.1f}_sir{}/valid/{}".format(prefix, self.rho, self.sir, name)
        else:
            file_name = "savedData/{}/rho{:.1f}_sir{}/test/{}".format(prefix, self.rho, self.sir, name)

        mkfile(file_name)
        return open(file_name, mode)

    def produce_func(self, _idx):
        return produce_data_batch(self.rho, self.sir)

    def __open_all(self, mode):
        f_y = self.__open_file("y", mode)
        f_h = self.__open_file("h", mode)
        f_s = self.__open_file("s", mode)
        f_one_hot = self.__open_file("one_hot", mode)
        f_w = self.__open_file("w", mode)
        f_hat_s = self.__open_file("s_mld", mode)
        f_hat_w = self.__open_file("w_mld", mode)
        f_crc_s_batch = self.__open_file("crc_s_batch", mode)  # 保存检测错误的包数据
        return f_y, f_h, f_s, f_one_hot, f_w, f_hat_s, f_hat_w, f_crc_s_batch

    def __delete_file(self, name):
        if self.flag == 0:
            file_name = "savedData/rho{:.1f}_sir{}/train/{}".format(self.rho, self.sir, name)
        elif self.flag == 1:
            file_name = "savedData/rho{:.1f}_sir{}/valid/{}".format(self.rho, self.sir, name)
        else:
            file_name = "savedData/rho{:.1f}_sir{}/test/{}".format(self.rho, self.sir, name)
        if os.path.exists(file_name):
            os.remove(file_name)

    def delete_all(self):
        self.__delete_file("y")
        self.__delete_file("h")
        self.__delete_file("s")
        self.__delete_file("one_hot")
        self.__delete_file("w")
        self.__delete_file("s_mld")
        self.__delete_file("w_mld")
        self.__delete_file("crc_s_batch")

    def produce_all(self):
        file_y, file_h, file_s, file_one_hot, file_w, file_hat_s, \
        file_hat_w, file_crc_s_batch = self.__open_all("wb")

        if self.flag == 0:
            total_batch = TRAIN_TOTAL_BATCH
        elif self.flag == 1:
            total_batch = VALID_TOTAL_BATCH
        else:
            total_batch = TEST_TOTAL_BATCH

        if NUM_WORKERS > 0:
            pool = multiprocessing.pool.Pool(NUM_WORKERS, maxtasksperchild=MAX_TASKS_PER_CHILD)
        else:
            pool = multiprocessing.pool.Pool(maxtasksperchild=MAX_TASKS_PER_CHILD)
        idx = 0

        error_packet = 0

        for ret_value in pool.imap(self.produce_func, range(total_batch)):
            if self.flag == 0:
                print("Train set，batch {}/{}".format(idx + 1, total_batch), end="\r")
            elif self.flag == 1:
                print("Valid set，batch {}/{}".format(idx + 1, total_batch), end="\r")
            else:
                print("Test set，batch {}/{}".format(idx + 1, total_batch), end="\r")

            flag = check_packet(ret_value[5].flatten(), ret_value[7].flatten())  # 计算总的误码数

            if flag:
                # 如果改包出错将对应的批次数据全部保存
                ret_value[0].astype(np.float32).tofile(file_y)
                ret_value[1].astype(np.float32).tofile(file_h)
                ret_value[2].astype(np.float32).tofile(file_s)  # 编码后的数据
                ret_value[3].astype(np.float32).tofile(file_one_hot)
                ret_value[4].astype(np.float32).tofile(file_w)
                ret_value[5].astype(np.float32).tofile(file_hat_s)  # 检测后的数据
                ret_value[6].astype(np.float32).tofile(file_hat_w)
                ret_value[7].astype(np.float32).tofile(file_crc_s_batch)
            #
            # if flag:
            #     error_packet += 1
            #     ret_value[5].astype(np.float32).tofile(file_hat_s)  # 如果检测到该包出错，就保存该包
            #     ret_value[7].astype(np.float32).tofile(file_crc_s_batch)  # 将对应的s也保存

            file_y.flush()
            file_h.flush()
            file_s.flush()
            file_one_hot.flush()
            file_w.flush()
            file_hat_s.flush()
            file_hat_w.flush()
            file_crc_s_batch.flush()

            idx += 1
        pool.close()

        file_y.close()
        file_h.close()
        file_s.close()
        file_one_hot.close()
        file_w.close()
        file_hat_s.close()
        file_hat_w.close()
        file_crc_s_batch.close()

        self.error_packet = error_packet  # 误包数
        # self.detect_error_bits = detect_error_bits  # 错误比特数
        # self.decode_error_bits = decode_error_bits

        print()
        print("数据集生成完毕")
        # print("信噪比：{}  检测器误比特率：{:e}".format(self.sir, self.detect_error_bits / (total_batch * PACKET_SIZE)))
        # print("信噪比：{}  解码后误比特率：{:e}".format(self.sir, self.decode_error_bits / (total_batch * PACKET_SIZE / 2)))

    def fetch(self):
        file_y, file_h, file_s, file_one_hot, file_w, file_hat_s, \
        file_hat_w, file_crc_s_batch = self.__open_all("rb")
        if self.flag == 0:
            total_batch = TRAIN_TOTAL_BATCH
        elif self.flag == 1:
            total_batch = VALID_TOTAL_BATCH
        else:
            total_batch = TEST_TOTAL_BATCH

        for i in range(total_batch):
            file_y.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)
            file_h.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * NUM_ANT)
            file_s.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)
            file_one_hot.seek(i * TIMES_SLOTS_PER_BATCH * BPSK_CANDIDATE_SIZE)
            file_w.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)
            file_hat_s.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)
            file_hat_w.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)
            file_crc_s_batch.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)

            y = np.fromfile(
                file_y,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            h = np.fromfile(
                file_h,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * NUM_ANT
            ).reshape([-1, NUM_ANT, NUM_ANT])

            s = np.fromfile(
                file_s,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            one_hot = np.fromfile(
                file_one_hot,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * BPSK_CANDIDATE_SIZE
            ).reshape([-1, BPSK_CANDIDATE_SIZE])

            w = np.fromfile(
                file_w,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            hat_s = np.fromfile(
                file_hat_s,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            hat_w = np.fromfile(
                file_hat_w,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            crc_s_batch = np.fromfile(
                file_crc_s_batch,
                dtype=np.float32,
                count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            ).reshape([-1, NUM_ANT, 1])

            yield y, h, s, one_hot, w, hat_s, hat_w, crc_s_batch

        file_y.close()
        file_h.close()
        file_s.close()
        file_one_hot.close()
        file_w.close()
        file_hat_s.close()
        file_hat_w.close()
        file_crc_s_batch.close()


def check_mld_batch(rho, sir_db):
    """
    zf-mld_error
    mmse-mld_error
    """
    err_mld = 0.0
    total_bits = 0.0
    idx = 0
    while idx < 1000:
        y, h, s, one_hot, w, s_mld, w_mld = produce_data_batch(rho, sir_db)
        bits = get_bits(s)
        bits_mld = get_bits(s_mld)
        err_mld += len(np.argwhere(bits_mld != bits))
        total_bits += bits.size
        ber_mld = err_mld / total_bits
        print("MLD, rho={}, sir={}dB, batch={:04}/1000, BER={:e}({:,.0f}/{:,.0f})".format(rho, sir_db, idx + 1, ber_mld,
                                                                                          err_mld, total_bits),
              end="\r")
        idx += 1
    print("")


def check_data_set_sir(rho: float, sir_db: float):
    hs_batch = None
    w_batch = None
    for i in range(100):   # 生成x个batch数据集
        y, h, s, one_hot, w, hat_s, hat_w = produce_data_batch(rho, sir_db)
        print("正在生成数据集 {}/100".format(i + 1), end="\r")
        hs_batch = concatenate(hs_batch, h @ s)
        w_batch = concatenate(w_batch, w)
    test_sir = np.sum(hs_batch ** 2) / np.sum(w_batch ** 2)
    test_sir_db = 10 * np.log10(test_sir)
    print("")
    print("数据集rho={}, 目标SIR={}dB, 检验SIR={:.2f}dB".format(rho, sir_db, test_sir_db))


def check_zf_sic(sir_db):
    power = 10 ** (sir_db / 10)
    h = np.sqrt(power / NUM_ANT) * np.random.randn(NUM_ANT, NUM_ANT)
    s = np.reshape(BPSK_CANDIDATES[:, 0:1], [NUM_ANT, 1])
    w = np.random.randn(NUM_ANT, 1)

    y = h @ s + w

    print(s)
    print(zf_sic(y, h))


def check_gen_data(rho, sir_db):
    err=0.0
    total_bits = 0.0

    idx = 0
    while idx < 1000:
        y, h, s, one_hot, w, hat_s, hat_w = produce_data_batch(rho, sir_db)

        bits = get_bits(s)
        total_bits += bits.size

        bits_detected = get_bits(hat_s)
        err += len(np.argwhere(bits_detected != bits))
        ber = err/total_bits

        idx += 1
        print("rho={}, sir={}dB, batch={:04}/1000, BER={:e}".format(rho, sir_db, idx, ber), end="\r")
    print("")


def check_detectors(rho, sir_db):
    power = 10 ** (sir_db / 10)

    err_zf = 0.0
    err_mmse=0.0
    err_zfmld=0.0
    err_mmsemld=0.0
    err_mld = 0.0
    total_bits = 0.0
    idx = 0
    while idx < 1000:
        h = np.sqrt(power / NUM_ANT) * random_h_batch()
        s, one_hot = random_s_batch()
        w = time_correlated_interference_batch(rho)
        y = h @ s + w

        bits = get_bits(s)
        total_bits += bits.size

        # zero forcing
        s_zf = zf_batch(y, h)
        bits_zf = get_bits(s_zf)
        err_zf += len(np.argwhere(bits_zf != bits))
        ber_zf = err_zf/total_bits

        # mmse
        s_mmse = mmse_batch_fast(y, h)
        bits_mmse = get_bits(s_mmse)
        err_mmse += len(np.argwhere(bits_mmse != bits))
        ber_mmse = err_mmse/total_bits

        # zero forcing mld
        s_zfmld = xxx_mld_batch(zf_batch, y, h)
        bits_zfmld = get_bits(s_zfmld)
        err_zfmld += len(np.argwhere(bits_zfmld != bits))
        ber_zfmld = err_zfmld/total_bits

        # mmse mld
        s_mmsemld = xxx_mld_batch(mmse_batch_fast, y, h)
        bits_mmsemld = get_bits(s_mmsemld)
        err_mmsemld += len(np.argwhere(bits_mmsemld != bits))
        ber_mmsemld = err_mmsemld/total_bits

        # mld
        s_mld = mld_batch(y, h)
        bits_mld = get_bits(s_mld)
        err_mld += len(np.argwhere(bits_mld != bits))
        ber_mld = err_mld/total_bits

        idx += 1
        print("rho={}, sir={}dB, batch={:04}/1000, ZF_BER={:e}, MMSE_BER={:e}, ZF_MLD_BER={:e}, MMSE_MLD_BER={:e}, MLD_BER={:e}".format(rho, sir_db, idx, ber_zf, ber_mmse, ber_zfmld, ber_mmsemld, ber_mld), end="\r")
    print("")


if __name__ == "__main__":
    # sir_list = [5, 10, 15, 20, 25, 30]
#     #
#     # for it in sir_list:
#     #     data = DataSet(flag=0, rho=0.5, sir=it)   # 产生训练数据
#     #     data.produce_all()
    # 产生训练数据
    data = DataSet(flag=0, rho=0.5, sir=10)
    data.produce_all()
    # 产生验证数据
    data = DataSet(flag=1, rho=0.5, sir=10)
    data.produce_all()
