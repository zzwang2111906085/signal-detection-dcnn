from dcnn import *
from func import *
from global_settings import *


def benchmark(max_k):
    """测试"""
    # snr_list = [9]
    # snr_list = [10]
    # rho = 0.95
    np.set_printoptions(formatter={'float': '{:e}'.format})

    # rho_list = [0.7]
    # rho_list = [0.2]
    rho_list = [0.6]
    # rho_list = [0.0]
    # rho_list = [0.5]
    snr = 15
    for rho in rho_list:
        D = TAIL  # 6
        memory = np.array([D])
        g_matrix = np.array([[1 + D ** 2, 1 + D + D ** 2]])  # G(D) = [1+D^2, 1+D+D^2]
        trellis = cc.Trellis(memory, g_matrix)

        model = DCNN(rho=rho, sir_db=snr)

        model.train()  # 训练模型
        # model.close()

        model.load()  # 加载模型

        decode_error_bits = 0
        model_err_bits_list = np.array([0] * max_k)

        mld_err_packet = 0
        model_err_packets_list = np.array([0] * max_k)

        packets = 0
        total_bits = 0

        print("Testing rho={:.1f} sir={}".format(rho, snr))
        while True:

            # TODO 产生测试数据, y, h, s,one_hot, w, hat_s, hat_w, packet_bits(原始[0, 1]数据)
            packet_data, x = generate_bits(rho=rho, snr=snr, enable_codec=True, trill=trellis)
            total_bits += x.size
            packets += 1  # 包数加1

            y = packet_data[0].reshape([-1, NUM_ANT * 2, 1])
            h = packet_data[1].reshape([-1, NUM_ANT * 2, NUM_ANT * 2])
            x = x  # flat raw bits
            s = packet_data[2].reshape([-1, NUM_ANT * 2, 1])
            c = get_qpsk_bits(s)
            hat_s = packet_data[5]
            hat_w = packet_data[6].reshape([-1, NUM_ANT * 2, 1])
            hat_c = get_qpsk_bits(hat_s)
            hat_x = cc.viterbi_decode(hat_c.flatten(), trellis)[:-D]
            mld_err_bits = count_error(hat_x, x)
            decode_error_bits += mld_err_bits
            mld_ber = decode_error_bits / total_bits
            mld_per = mld_err_packet / packets

            if mld_err_bits == 0:
                pass
            else:
                mld_err_packet += 1

                for k in range(max_k):
                    tilde_w = model.evaluate(hat_w)
                    tilde_y = y - tilde_w
                    if DETECTOR_TYPE == MMSE:
                        tilde_s = xxx_mld_batch(mmse_batch_fast, tilde_y, h)
                        # hat_s = mmse_batch_fast(y, h)
                    elif DETECTOR_TYPE == ZF:
                        tilde_s = xxx_mld_batch(zf_batch, tilde_y, h)
                        # hat_s = zf_batch(y, h)
                    elif DETECTOR_TYPE == MLD:
                        tilde_s = xxx_mld_batch(mld_ird, tilde_y, h)
                        # hat_s = mld_ird(y, h)
                    else:
                        raise Exception("Unknown detector")

                    tilde_c = get_qpsk_bits(tilde_s)
                    hat_x = cc.viterbi_decode(tilde_c.flatten(), trellis)[:-D]
                    k_err_bits = count_error(hat_x, x)
                    model_err_bits_list[k] += k_err_bits
                    if k_err_bits > 0:
                        model_err_packets_list[k] += 1
                    else:
                        break
                    if k != max_k - 1:
                        hat_w = y - h @ tilde_s

            model_ber_list = model_err_bits_list / total_bits
            model_per_list = model_err_packets_list / packets

            print("DETECTOR_BER={:e} MODEL_BER={} DETECTOR_PER={:e} MODEL_PER={} packets={}".format(
                mld_ber,
                model_ber_list,
                mld_per,
                model_per_list,
                packets), end="\r")

            precision = 1 / total_bits

            if ((model_ber_list / precision) > 200).all() and packets >= 5000:
                break

        model.close()
        print()


if __name__ == "__main__":
    benchmark(max_k=3)
