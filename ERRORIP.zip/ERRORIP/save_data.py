import os
import pathlib
from global_settings import *
from func import *


def mkdir(file_path):
    folder = os.path.dirname(file_path)
    if not os.path.exists(folder):
        os.makedirs(folder)


def mkfile(file_path):
    mkdir(file_path)
    filename = pathlib.Path(file_path)
    filename.touch(exist_ok=True)


class DataSet:
    def __init__(self, flag, rho: float, sir: float):
        self.flag = flag
        self.rho = rho
        self.sir = sir
        self.error_packet = 0
        self.error_bits = 0

    def __open_file(self, name, mode):

        if DETECTOR_TYPE == ZFMLD:
            prefix = "zf_mld"
        elif DETECTOR_TYPE == MMSEMLD:
            prefix = "mmse_mld"
        elif DETECTOR_TYPE == MMSE:
            prefix = "mmse"
        elif DETECTOR_TYPE == ZF:
            prefix = "zf"
        else:
            raise Exception("Unknown detector")

        if CHANNEL_TYPE == RANDOM_H:
            prefix += "/random"
        elif CHANNEL_TYPE == MAXMIN_H:
            prefix += "/maxmin"
        elif CHANNEL_TYPE == SVD_H:
            prefix += "/svd"
        else:
            raise Exception("Unknown user selection type")

        if self.flag == 0:
            file_name = "savedData/{}/rho{:.1f}_sir{}/train/{}".format(prefix, self.rho, self.sir, name)
        elif self.flag == 1:
            file_name = "savedData/{}/rho{:.1f}_sir{}/valid/{}".format(prefix, self.rho, self.sir, name)
        else:
            file_name = "savedData/{}/rho{:.1f}_sir{}/test/{}".format(prefix, self.rho, self.sir, name)

        mkfile(file_name)
        return open(file_name, mode)

    def __open_all(self, mode):
        f_y = self.__open_file("y", mode)
        f_h = self.__open_file("h", mode)
        f_s = self.__open_file("s", mode)
        f_one_hot = self.__open_file("one_hot", mode)
        f_w = self.__open_file("w", mode)
        f_hat_s = self.__open_file("s_mld", mode)
        f_hat_w = self.__open_file("w_mld", mode)
        # f_crc_s_batch = self.__open_file("crc_s_batch", mode)  # 保存检测错误的包数据
        return f_y, f_h, f_s,f_one_hot, f_w, f_hat_s, f_hat_w

    def open_all_file(self, mode):
        """打开所有文件"""
        return self.__open_all(mode)

    def fetch(self,count=(TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)):
        file_y, file_h, file_s, file_one_hot, file_w, file_hat_s, file_hat_w = self.__open_all("rb")
        if self.flag == 0:
            total_batch = TOTAL_TRAIN_MINI_BATCH  # 传入网络的训练batch
        elif self.flag == 1:
            total_batch = TOTAL_VALID_MINI_BATCH
        else:
            total_batch = TOTAL_TEST_MINI_BATCH

        for i in range(total_batch):   # 从文件中获取数据
            # 定位光标
            file_y.seek(i * TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2 )
            file_h.seek(i * TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2 * 2 * NUM_ANT)
            file_s.seek(i * count)
            file_one_hot.seek(i * TIMES_SLOTS_PER_MINI_BATCH * QPSK_CANDIDATE_SIZE)
            file_w.seek(i * TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            file_hat_s.seek(i * TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            file_hat_w.seek(i * TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            # file_crc_s_batch.seek(i * TIMES_SLOTS_PER_BATCH * NUM_ANT * 1)

            # 获取数据
            y = np.fromfile(
                file_y,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 1])

            h = np.fromfile(
                file_h,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * 2 * NUM_ANT * 2 * NUM_ANT)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 2 * NUM_ANT])

            s = np.fromfile(
                file_s,
                dtype=np.float32,
                count=count
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 1])

            one_hot = np.fromfile(
                file_one_hot,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * QPSK_CANDIDATE_SIZE)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, QPSK_CANDIDATE_SIZE])

            w = np.fromfile(
                file_w,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 1])

            hat_s = np.fromfile(
                file_hat_s,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 1])

            hat_w = np.fromfile(
                file_hat_w,
                dtype=np.float32,
                count=(TIMES_SLOTS_PER_MINI_BATCH * NUM_ANT * 2)
            ).reshape([TIMES_SLOTS_PER_MINI_BATCH, 2 * NUM_ANT, 1])

            # crc_s_batch = np.fromfile(
            #     file_crc_s_batch,
            #     dtype=np.float32,
            #     count=TIMES_SLOTS_PER_BATCH * NUM_ANT * 1
            # ).reshape([-1, NUM_ANT, 1])
            yield y, h, s, one_hot, w, hat_s, hat_w

        file_y.close()
        file_h.close()
        file_s.close()
        file_one_hot.close()
        file_w.close()
        file_hat_s.close()
        file_hat_w.close()
        # file_crc_s_batch.close()

#
def test_bechmark(snr, flag=2):
    """进行测试"""

    test_data = DataSet(flag=flag, rho=0.5, sir=snr)
    file_y, file_h, file_s, file_w, file_hat_s, file_hat_w = test_data.open_all_file("wb")

    total_packets = TOTAL_TEST_MINI_BATCH * MINI_BATCH

    error_bits = 0
    packets = 0

    for i in range(total_packets):
        packet_test_data, packet_bits = generate_bits(rho=0.5, snr=snr, enable_codec=True)

        # err = count_error(packet_test_data[2], packet_test_data[4])  # 计算检测器误码数

        if flag == 2:
            packet_test_data[2] = packet_bits  # 保存原始数据
            save_batch_data(packet_test_data, file_y, file_h, file_s, file_w, file_hat_s, file_hat_w)  # 保存测试数据

    #     error_bits += err  # 误码数
    #
    #     packets += 1
    #
    #     ber = error_bits / (BITN * packets)
    #
    #     tag = "With Codec"
    #
    #     print("MIMO {}x{} QPSK {}\tSNR:{:02}\t\tBER: {:e}({}/{})\tPACKET_COUNT:({}/{})".format(
    #         NUM_ANT, NUM_ANT, tag, snr, ber, error_bits, (BITN * packets),
    #         packets, total_packets), end="\r")
    #
    print()
    file_y.close()
    file_h.close()
    file_s.close()
    file_w.close()
    file_hat_s.close()
    file_hat_w.close()
    # file_crc_s_batch.close()
    print("{}数据收集完毕！".format(snr))


if __name__ == '__main__':
    snr_list = [9]
    for snr in snr_list:
        test_bechmark(snr, flag=2)
        test_bechmark(snr, flag=2)




