# """该模块包含了程序所需要的全局设置参数"""
import numpy as np

import itertools

# # 用户数量
NUM_USERS = 10

# 发射端和接收端的天线数量
NUM_ANT = 4

# 归一化之后的多普勒频率
NORMALIZED_DOPPLER_FREQUENCY = 0.1

TAIL = 6  # 原始数据尾部长度

# 用于crc
CRC_TABLE = 256
CRC_BITN = 32
CRC32_POLY = 0x04c11db7

TOTAL_BATCH = 1000

# 用于编码

# 用于解码
STATEN = 64  # 64种状态
BITN = 512  # 包的长度
PACK_SIZE = BITN
DATA_BITN = int(BITN / 2)  # 编码钱长度

# ORIGINAL_DATA = DATA_BITN - CRC_BITN - TAIL  # 原始数据长度
# DATA_LENGTH = DATA_BITN - CRC_BITN - TAIL  # 原始数据长度

ORIGINAL_DATA = DATA_BITN - TAIL  # 原始数据长度
DATA_LENGTH = DATA_BITN - TAIL  # 原始数据长度

OneBySqrt2 = 0.7071067812

TIMES_SLOTS_ORIGINAL_DATA = int(ORIGINAL_DATA / NUM_ANT)  # 64

# 每个数据包需要的传输次数
TIMES_SLOTS_PER_PACKET = int(BITN / (NUM_ANT * 2))  # 64

# 每批次数据所包含的数据包数量
PACKETS_PER_BATCH = 10

# 每批次数据需要的传输次数
# TIMES_SLOTS_PER_BATCH = PACKETS_PER_BATCH * TIMES_SLOTS_PER_PACKET

MINI_BATCH = 10  # 一次放10个包进网络
TIMES_SLOTS_PER_MINI_BATCH = MINI_BATCH * TIMES_SLOTS_PER_PACKET

ORIGINAL_DATA_MINI_BATCH = MINI_BATCH * DATA_LENGTH

TOTAL_TRAIN_MINI_BATCH = 10000
TOTAL_VALID_MINI_BATCH = 400

TOTAL_TEST_MINI_BATCH = 1000
#
# # 训练集的总批次
# TRAIN_TOTAL_BATCH = 1000
#
# # 验证集的总批次
# VALID_TOTAL_BATCH = 400
#
# # 测试集的总批次
# TEST_TOTAL_BATCH = 3000

# 多进程并行生成数据的进程数量，一般小于等于你电脑的CPU核心数量，0代表自动识别
NUM_WORKERS = 6

# 每个子进程的任务数量（防止内存溢出）
MAX_TASKS_PER_CHILD = 100

# 最大训练代数
MAX_EPOCHS = 10

# 每间隔多少代训练后验证一次模型
VALID_MODEL_EVERY_EPOCHES = 1

# 最大震荡次数（没耐心的设置为1）
MAX_FLIP = 4

ZFMLD = 0
MMSEMLD = 1
MMSE = 2
ZF = 3
MLD = 4

DETECTOR_TYPE = MMSE

RANDOM_H = 0
MAXMIN_H = 1
SVD_H = 2

CHANNEL_TYPE = RANDOM_H

# QPSK_CANDIDATE_SIZE = 4 ** NUM_ANT
# QPSK_CANDIDATES = np.array([x for x in itertools.product([1, -1], repeat=2 * NUM_ANT)]).T / np.sqrt(2)
