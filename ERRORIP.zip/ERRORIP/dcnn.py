from demo import *
import tensorflow as tf
import os
from func import *
from global_settings import *


def batch_multiply(a, b):
    return tf.einsum("ijk,ikl->ijl", a, b)


class DCNN:
    def __init__(self, rho, sir_db=10):
        self.rho = rho
        self.sir_db = sir_db
        self.total_layer = 4
        # self.feature_maps = [64, 32, 16, 1]
        # self.feature_sizes = [9, 3, 3, 15]
        self.feature_maps = [32, 16, 8, 1]
        self.feature_sizes = [36, 3, 3, 36]

        if DETECTOR_TYPE == ZFMLD:
            prefix = "zf_mld"
        elif DETECTOR_TYPE == MMSEMLD:
            prefix = "mmse_mld"
        elif DETECTOR_TYPE == MMSE:
            prefix = "mmse"
        elif DETECTOR_TYPE == ZF:
            prefix = "zf"
        else:
            raise Exception("Unknown detector")

        if CHANNEL_TYPE == RANDOM_H:
            prefix += "_random"
        elif CHANNEL_TYPE == MAXMIN_H:
            prefix += "_maxmin"
        elif CHANNEL_TYPE == SVD_H:
            prefix += "_svd"
        else:
            raise Exception("Unknown user selection type")

        self.unique_name = "{}_model_ant{}_rho{:.1f}_sir{}".format(prefix, NUM_ANT, rho, sir_db)

        self.__make_graph()

        gpu_options = tf.GPUOptions()
        gpu_options.allow_growth = True
        self.sess = tf.Session(graph=self.graph, config=tf.ConfigProto(gpu_options=gpu_options))

    def __make_graph(self):
        self.graph = tf.Graph()
        with self.graph.as_default():
            # 定义占位符, none 是待定，一般用于placeholder, -1是根据获得的数据进行自运算，一般用于reshape
            self.y = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 1], "y")
            self.h = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 2 * NUM_ANT], "h")
            self.s = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 1], "s")
            self.one_hot = tf.placeholder(tf.float32, [None, QPSK_CANDIDATE_SIZE], "one_hot")
            self.w = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 1], "w")
            self.hat_s = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 1], "hat_s")
            self.hat_w = tf.placeholder(tf.float32, [None, 2 * NUM_ANT, 1], "hat_w")


            # 定义卷积层
            layer_input = {}
            layer_output = {}
            in_channels = {}
            out_channels = {}
            for layer_id in range(self.total_layer):
                with tf.variable_scope("conv_layer_{}".format(layer_id)):
                    if layer_id == 0:
                        # 实部和虚部排列为两个通道进行卷积，需要将虚部和实部分开
                        w_in = tf.reshape(self.hat_w, [-1, TIMES_SLOTS_PER_PACKET, 2, NUM_ANT])
                        w_in = tf.transpose(w_in, perm=[0, 1, 3, 2])
                        w_in = tf.reshape(w_in, [-1, PACK_SIZE, 1, 1])

                        layer_input[layer_id] = w_in
                        in_channels[layer_id] = 1
                    else:
                        layer_input[layer_id] = layer_output[layer_id - 1]
                        in_channels[layer_id] = self.feature_maps[layer_id - 1]
                    out_channels[layer_id] = self.feature_maps[layer_id]

                    W = tf.get_variable(name="weights",
                                        shape=[self.feature_sizes[layer_id],
                                               1,
                                               in_channels[layer_id],
                                               out_channels[layer_id]
                                               ],
                                        dtype=tf.float32,
                                        initializer=tf.contrib.layers.xavier_initializer()
                                        )

                    conv = tf.nn.conv2d(input=layer_input[layer_id],
                                        filter=W,
                                        strides=[1, 1, 1, 1],
                                        padding="SAME")

                    B = tf.get_variable(name="bias",
                                        shape=[out_channels[layer_id]], dtype=tf.float32,
                                        initializer=tf.contrib.layers.xavier_initializer())

                    if layer_id == self.total_layer - 1:
                        layer_output[layer_id] = conv + B
                    else:
                        layer_output[layer_id] = tf.nn.relu(conv + B)

            out = layer_output[self.total_layer - 1]
            # 恢复原来的形状
            w_out = tf.reshape(out, [-1, TIMES_SLOTS_PER_PACKET, NUM_ANT, 2])
            w_out = tf.transpose(w_out, perm=[0, 1, 3, 2])
            w_out = tf.reshape(w_out, [-1, 2 * NUM_ANT, 1])

            self.cnn_w = w_out
            # self.loss = tf.reduce_mean(tf.reduce_sum(tf.square(self.cnn_w - self.w), axis=[1, 2]))

            # 换一种损失函数试试
            self.candidates = tf.constant(QPSK_CANDIDATES, dtype=tf.float32)
            temp_dis = (self.y - self.cnn_w) - tf.tensordot(self.h, self.candidates, axes=1)
            self.distance = tf.reduce_sum(tf.square(temp_dis), axis=1)
            self.loss = tf.reduce_mean(
                tf.nn.softmax_cross_entropy_with_logits_v2(labels=self.one_hot, logits=-self.distance)
            )

            # out_hat_s = tf.reshape(layer_output[self.total_layer - 1], [TIMES_SLOTS_PER_BATCH, NUM_ANT])

            # self.pred = tf.layers.dense(out_hat_s, units=BPSK_CANDIDATE_SIZE, activation=None, name="predict_layer")
            # self.loss = tf.reduce_mean(
            #     tf.nn.softmax_cross_entropy_with_logits(labels=self.error_hat_s_one_hot, logits=self.pred))
            #
            # self.pre = tf.reshape(layer_output[self.total_layer - 1], [TIMES_SLOTS_PER_BATCH, NUM_ANT, 1])
            # self.loss = tf.reduce_mean(tf.reduce_sum(tf.square(self.pre - self.error_hat_s_s), axis=[1, 2]))
            # self.loss = tf.losses.categorical_crossentropy(self.w, self.w_cnn)
            # self.loss = tf.reduce_mean(tf.reduce_sum(tf.square(np.log(np.abs(self.w_cnn)) - np.log(np.abs(self.w))), axis=[1, 2]))
            # 防止较大离散值影响

            self.global_step = tf.Variable(tf.constant(0), trainable=False, name="global_step")
            self.optimizer = tf.train.AdamOptimizer().minimize(self.loss, global_step=self.global_step)
            self.init_variables = tf.global_variables_initializer()

    def load(self):
        with self.graph.as_default():
            saver = tf.train.Saver(tf.global_variables())
            path = "savedModel/{}/".format(self.unique_name)
            saver.restore(self.sess, path)
            print("Model \"{}\" loaded".format(self.unique_name))

    def save(self):
        with self.graph.as_default():
            saver = tf.train.Saver(tf.global_variables())
            path = "savedModel/{}/".format(self.unique_name)
            folder = os.path.dirname(path)
            if not os.path.exists(folder):
                os.makedirs(folder)
            prefix = saver.save(self.sess, path)
            print("Model saved at \"{}\"".format(prefix))

    def close(self):
        self.sess.close()

    def train(self):
        print("Initializing model {}".format(self.unique_name))
        self.sess.run(self.init_variables)

        train_io = DataSet(flag=0, rho=self.rho, sir=self.sir_db)

        flip_count = 0
        best_loss = None
        epoch = 0
        while epoch < MAX_EPOCHS:
            batch_idx = 0
            for y, h, s, one_hot, w, hat_s, hat_w in train_io.fetch():
                _, loss = self.sess.run(
                    [self.optimizer, self.loss],
                    feed_dict={
                        self.y: y,
                        self.h: h,
                        self.s: s,
                        self.one_hot: one_hot,
                        self.w: w,
                        self.hat_s: hat_s,
                        self.hat_w: hat_w
                    }
                )
                print("Training model \"{}\", epoch {}/{}, batch={}, loss={:e}".format(
                    self.unique_name, epoch + 1, MAX_EPOCHS, batch_idx + 1, loss), end='\r')
                batch_idx += 1
            print()
            epoch += 1

            if epoch % VALID_MODEL_EVERY_EPOCHES == 0:
                new_loss = self.__valid_model()  # 网络误码率
                if best_loss is None or new_loss < best_loss:  # 这个if是防止训练震荡
                    best_loss = new_loss
                    self.save()
                else:
                    flip_count += 1
                    if flip_count >= MAX_FLIP:
                        break
        print("Model \"{}\" train over".format(self.unique_name))

    def __valid_model(self):
        total_loss = 0
        total_batch = 0

        valid_io = DataSet(flag=1, rho=self.rho, sir=self.sir_db)
        for y, h, s, one_hot, w, hat_s, hat_w in valid_io.fetch():
            print("Validating model \"{}\", batch={}".format(self.unique_name, total_batch+1), end="\r")
            total_loss += self.sess.run(
                self.loss,
                feed_dict={
                    self.y: y,
                    self.h: h,
                    self.s: s,
                    self.one_hot: one_hot,
                    self.w: w,
                    self.hat_s: hat_s,
                    self.hat_w: hat_w
                }
            )
            total_batch += 1
        print()
        avg_loss = total_loss/total_batch
        print("Model validated, AvgLoss={:e}".format(avg_loss))
        return avg_loss

    # def detect_bits_batch(self, error_hat_s):
    #     return self.sess.run(self.pred, feed_dict={self.error_hat_s: error_hat_s})

    def evaluate(self, hat_w):
        return self.sess.run(self.cnn_w, feed_dict={self.hat_w: hat_w})

    def detect_bits_batch(self, y, h, hat_w_in, k=1):
        hat_w = hat_w_in
        for _ in range(k):
            tilde_w = self.evaluate(hat_w)
            if DETECTOR_TYPE == MMSE:
                tilde_s = xxx_mld_batch(mmse_batch_fast, y - tilde_w, h)
                # hat_s = mmse_batch_fast(y, h)
            elif DETECTOR_TYPE == ZF:
                tilde_s = xxx_mld_batch(zf_batch, y - tilde_w, h)
                # hat_s = zf_batch(y, h)
            elif DETECTOR_TYPE == MLD:
                tilde_s = xxx_mld_batch(mld_ird, y - tilde_w, h)
                # hat_s = mld_ird(y, h)
            else:
                raise Exception("Unknown detector")
            if k != k - 1:
                hat_w = y - h @ tilde_s
        return get_qpsk_bits(tilde_s), tilde_w

#
# if __name__ == "__main__":
    # snr_list = [8, 9, 10, 11, 12, 13, 14]
    # rho = 0.5

    # rho_list = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    # snr = 20
    # for rho in rho_list:
    #     cnn = DCNN(rho=rho, sir_db=snr)
    #     cnn.train()

