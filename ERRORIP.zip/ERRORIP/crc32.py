import numpy as np
from global_settings import *


# void init_crc32(void);
# void crc32( int *data, int data_length, int *crc_bit );
# int crc32_check( int *data, int data_length, int *crc_bit );


def init_crc32():
    """初始化crc_table"""
    crc32_table = np.zeros([CRC_TABLE])
    for i in range(CRC_TABLE):
        i = i & 0xffffffff
        c = i << 24  # 将i左移24位
        for j in range(8, 0, -1):
            if c & 0x80000000:
                c = (c << 1) ^ CRC32_POLY
            else:
                c = c << 1

            c = c & 0xffffffff
        crc32_table[i] = c

    return crc32_table


def crc32(bits):
    """
    1）crc寄存器组初始化位0x00000000或oxffffffff
    2）crc寄存器组向左移16位，并保存crc寄存器组
    3）原crc寄存器组的高8位（右移24位）与数据字节进行异或运算，的出一个指向表索引
    4）索引所指的表值与crc寄存器做异或运算
    5）数据指针加1，如果数据没有处理完，重复第二步
    6）得出crc
    bits:原始数据
    """
    crc = 0xffffffff

    int_bits = bits

    crc_bit = []

    crc32_table = init_crc32()

    for bit_index in range(DATA_LENGTH):
        table_index = (crc >> 24) ^ int(int_bits[bit_index])
        crc = (crc << 8) ^ int(crc32_table[table_index])
        crc = crc & 0xffffffff

    for bit_index in range(CRC_BITN):
        crc_bit.append(((crc >> bit_index) + 1) & 0x1)

    return np.array(crc_bit)


def crc32_check(bits: np.ndarray, crc_bits: np.ndarray):
    """
    bits:解码后的比特流
    crc_bits:32位校验码
    """
    crc_check = crc32(bits)

    return len(np.argwhere(crc_check != crc_bits))

#
# if __name__ == "__main__":
#
#     bits = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]
#     crc_bits = np.zeros(32)
#
#     crc32(bits)
#     print(crc_bits)

